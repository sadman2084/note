val=map(int,input("enter value ").split(","))
val=list(val)
n=len(val)-1
result=""
while n>=0:
    while(val[n]>0):
        result=result+"@"
        val[n]=val[n]-1
    print(result)
    print("\n")
    n=n-1


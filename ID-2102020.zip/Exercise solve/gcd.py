val1= int(input("Enter first number: "))
val2 = int(input("Enter second number: "))

while val2 != 0:
    temp = val2
    val2 = val1 % val2
    val1 = temp

print("GCD is:", val1)

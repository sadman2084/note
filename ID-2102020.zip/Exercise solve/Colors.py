colors=input("Enter colors separated by commas: ")
color_list=colors.split(",")
print("first color is ",color_list[0])
print("last color is ",color_list[-1])
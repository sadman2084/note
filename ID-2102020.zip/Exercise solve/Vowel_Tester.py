import time
import os

s1=input("enter string ")
num=len(s1)-1
while num>=0:
    if s1[num] == "a" or s1[num] == "e" or s1[num] == "i" or s1[num] == "o" or s1[num] == "u":
        print(s1[num], end="")
    num -= 1

time.sleep(2)
os.system("cls" if os.name =="nt" else "clear")
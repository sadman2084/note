file_name=input("Enter the file name: ")
file_extension=file_name.split(".")[-1]
print("File extension:", file_extension)
import time
import os

val=map(int,input("enter values ").split(","))
val=list(val)
find=int(input("enter value to find "))
num=len(val)-1
while num>=0:
    if val[num]==find:
        print("Value found at index", num)
        break
    num=num-1


time.sleep(2)
os.system("cls" if os.name=="nt" else "clear")
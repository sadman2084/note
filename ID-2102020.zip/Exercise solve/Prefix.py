s1=input("enter string ")
# print(s1[0])
# print(s1[1])
if (s1[0] and s1[1] )== "Is":
    print("It is a valid string")
else:
    print("Is"+s1)
import myheader
def recur(vl):
    if len(vl)==1:
        print("only one value", vl[0])
        return vl[0]
    else:
        return vl[0] + recur(vl[1:])
        

if __name__=="__main__":
    vl=map(int, input("Enter two values: ").split(","))
    vl=list(vl)
    result=recur(vl)
    print("Sum is:", result)
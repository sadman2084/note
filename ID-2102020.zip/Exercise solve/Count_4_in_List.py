vl=map(int,input("enter value ").split(","))

vl=list(vl)
print(vl)
i=len(vl)-1
count=0
while i>0:
    if vl[i]==4:
        count=count+1
    i=i-1

print(count)
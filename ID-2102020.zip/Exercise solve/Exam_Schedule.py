exam_time=input("Enter exam time ")
exam_times=exam_time.split(":")
print("Exam time is", exam_times[0], "hours and", exam_times[1], "minutes")


e1=map(int,input("Enter exam time ").split(":"))#for multiple inputs and it returns a map object
e2=list(e1)#converting it into list
print("Exam time is", e2[0], "hours and", e2[1], "minutes")
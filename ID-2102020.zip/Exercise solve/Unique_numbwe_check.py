vl=map(int,input("Enter two values: ").split(","))
vl=list(vl)
n=len(vl)-1
c=0
while n>=0:
    if vl[n]==vl[n-1]:
        # print("gotcha")
        c=1

        break
    else:
        n-=1
    

if c==0:
    print("no unique number found")
else:
    print("unique number found")

v=int(input("enter number "))
sum=v
v=v*10+5
sum=sum+v
v=v*10+5
sum=sum+v
print(sum)
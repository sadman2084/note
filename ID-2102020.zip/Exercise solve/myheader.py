import time
import os

time.sleep(1)
os.system("cls" if os.name=="nt" else "clear")
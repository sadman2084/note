import time
import os

vl1=int(input("Enter first value: "))
vl2=int(input("Enter second value: "))
vl3=int(input("Enter third value: "))

if vl1==vl2 or vl2==vl3 or vl3==vl1:
    print("0")
else:
    sum= vl1 + vl2 + vl3
    print("Sum is:", sum)

time.sleep(2)
os.system("cls" if os.name=="nt" else "clear")
v=int(input("enter value "))
v=abs(v)
print(v)
vl1=int(input("Enter first value: "))
vl2=int(input("Enter second value: "))
sum=vl1+vl2

if 15<sum<20:
    print("20")

else:
    print("Sum is:", sum)
numbers = [    
    386, 462, 47, 418, 907, 344, 236, 375, 823, 566, 597, 978, 328, 615, 953, 345, 
    399, 162, 758, 219, 918, 237, 412, 566, 826, 248, 866, 950, 626, 949, 687, 217, 
    815, 67, 104, 58, 512, 24, 892, 894, 767, 553, 81, 379, 843, 831, 445, 742, 717, 
    958, 743, 527
]

num = []
n = len(numbers) - 1
while n >= 0:
    if numbers[n] % 2 == 0:
        num.append(numbers[n])  
    n -= 1

print("Even numbers in reverse:")
print(num)

print("\nReverse print until 237 is found:")
n = len(numbers) - 1
while n >= 0:
    if numbers[n] != 237:
        print(numbers[n], end=" ")
    else:
        break
    n -= 1

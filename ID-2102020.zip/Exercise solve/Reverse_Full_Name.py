first=input("enter 1st name: ")
second=input("enter 2nd name: ")
print(second+" "+first)
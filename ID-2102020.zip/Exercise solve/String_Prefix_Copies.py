s1=input("enter string ")
num=int(input("enter number for copies "))
s2=str(s1[0:num])
result=s2*num
print(result)

    

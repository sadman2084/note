#include<bits/stdc++.h>
#include<signal.h>

using namespace std;

void sig_int(int sig_num)
{
cout << "\nSIGINT received (Ctrl+C pressed)!" << endl;

}


int main()

{
signal(SIGINT,sig_int);
while(true){
    cout<<"running"<<endl;
    sleep(1);
}

}

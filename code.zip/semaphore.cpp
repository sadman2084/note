#include <iostream>
#include <thread>
#include <queue>

using namespace std;

const int MAX = 5;
queue<int> buffer;

int mutex_lock = 1;
int empty_slots = MAX;
int full_slots = 0;

void wait(int &s) {
    while (s <= 0);
    s--;
}

void signal(int &s) {
    s++;
}

void producer(int id) {
    for (int i = 0; i < 10; i++) {

        wait(empty_slots);
        wait(mutex_lock);

        buffer.push(i);
        cout << "Producer " << id << " produced " << i << endl;

        signal(mutex_lock);
        signal(full_slots);
    }
}

void consumer(int id) {
    for (int i = 0; i < 10; i++) {

        wait(full_slots);
        wait(mutex_lock);

        int item = buffer.front();
        buffer.pop();

        cout << "Consumer " << id << " consumed " << item << endl;

        signal(mutex_lock);
        signal(empty_slots);
    }
}

int main() {
    thread p1(producer, 1);
    thread c1(consumer, 1);

    p1.join();
    c1.join();

    return 0;
}
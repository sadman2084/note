#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>

using namespace std;

const int N = 5;

mutex mtx;
condition_variable cv[N];

int state[N]; // 0 = thinking, 1 = hungry, 2 = eating

int LEFT(int i) { return (i + N - 1) % N; }
int RIGHT(int i) { return (i + 1) % N; }

void test(int i) {
    if (state[i] == 1 &&
        state[LEFT(i)] != 2 &&
        state[RIGHT(i)] != 2) {

        state[i] = 2;
        cv[i].notify_one();
    }
}

void pickup(int i) {
    unique_lock<mutex> lock(mtx);

    state[i] = 1; // hungry
    test(i);

    while (state[i] != 2)
        cv[i].wait(lock);
}

void putdown(int i) {
    unique_lock<mutex> lock(mtx);

    state[i] = 0; // thinking

    test(LEFT(i));
    test(RIGHT(i));
}

void philosopher(int i) {
    while (true) {
        cout << "Philosopher " << i << " thinking\n";

        pickup(i);

        cout << "Philosopher " << i << " eating\n";

        putdown(i);
    }
}

int main() {
    thread t[N];

    for (int i = 0; i < N; i++)
        t[i] = thread(philosopher, i);

    for (int i = 0; i < N; i++)
        t[i].join();

    return 0;
}
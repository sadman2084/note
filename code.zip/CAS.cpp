#include <iostream>
#include <thread>
#include <vector>
#include <atomic>
#include <chrono>

using namespace std;

atomic<int> next_id(1);

void acquire_id(int i) {
    while (true) {
        int current = next_id.load();   
        int new_value = current + 1;

        if (next_id.compare_exchange_weak(current, new_value)) {
            cout << "Thread " << i << " Assigned ID: " << current << endl;
            break;
        } else {
            this_thread::sleep_for(chrono::milliseconds(1));
        }
    }
}

int main() {
    vector<thread> threads;

    for (int i = 0; i < 10; i++) {
        threads.push_back(thread(acquire_id, i));
    }

    for (auto &t : threads) {
        t.join();
    }

    return 0;
}
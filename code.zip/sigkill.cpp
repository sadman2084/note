#include <iostream>
#include <unistd.h>
#include <signal.h>

using namespace std;

int main() {
    pid_t pid = fork();

    if (pid == 0) {
        // child
        while (true);
    } 
    else {
        sleep(2);
        kill(pid, SIGKILL);
        cout << "Child killed\n";
    }
}
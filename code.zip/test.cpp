#include<bits/stdc++.h>
using namespace std;

void generate_id()
{
cout<<"thread example"<<endl;
}

int main()
{

thread t1=thread(generate_id);

t1.join();

}

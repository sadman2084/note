import threading

def square(num):
    print(f'Square of {num} is {num**2}')

def cube(num):
    print(f'Cube of {num} is {num**3}')

num=5
t1=threading.Thread(target=square,args=(num,))
t2=threading.Thread(target=cube,args=(num,))


t1.start()
t2.start()

t1.join()
t2.join()
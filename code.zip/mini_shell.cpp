#include<bits/stdc++.h>
#include<sys/wait.h>

using namespace std;

void sig_term(int sig_val)
{
cout<<"ctrl + c"<< " "<<sig_val<<endl;
exit(sig_val);
}

int main()


{

string s;
signal(SIGINT,sig_term);
while(true)
{

cout<<"mini shell"<<endl;
cin>>s;
if (s=="exit") break;

if(fork()==0)
{
execlp(s.c_str(),"",NULL);
// exit(1);
}

else{

wait(NULL);

}
}

}

import threading

def print_name(name,times):
    for i in range(times):
        print(f'{name} is printing {i+1} times')

t1=threading.Thread(target=print_name,args=('sadman',3))
t2=threading.Thread(target=print_name,args=('rahim',3))

t1.start()
t2.start()

t1.join()
t2.join()
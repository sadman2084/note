#include <iostream>
#include <thread>
#include <vector>
#include <chrono>
#include <atomic>

using namespace std;

int next_id = 1;

// atomic lock variable
atomic<bool> lock_var(false);

bool test_and_set() {
    return lock_var.exchange(true);
}

void acquire_lock() {
    while (test_and_set()) {
    }
}

void release_lock() {
    lock_var.store(false);
}

void generate_id(int i) {
    acquire_lock();

    int temp = next_id;
    this_thread::sleep_for(chrono::milliseconds(10));
    next_id = temp + 1;

    cout << "Thread " << i << " Assigned ID: " << temp << endl;

    release_lock();
}

int main() {
    vector<thread> threads;

    for (int i = 0; i < 10; i++) {
        threads.push_back(thread(generate_id, i));
    }

    for (auto &t : threads) {
        t.join();
    }

    return 0;
}